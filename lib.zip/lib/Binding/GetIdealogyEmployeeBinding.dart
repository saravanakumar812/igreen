// import 'package:get/get.dart';
// import '../Controller/GetEmployeeIdealogyController.dart';
//
//
// class GetIdeaLogyEmployeeBinding extends Bindings {
//   @override
//   void dependencies() {
//     Get.lazyPut<GetEmployeeIdeaLogyController>(() => GetEmployeeIdeaLogyController());
//   }
// }
