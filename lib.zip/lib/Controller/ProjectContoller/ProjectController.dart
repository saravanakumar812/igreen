import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class ProjectController extends GetxController {
  // RxBool isExpanded = false.obs;
  @override
  void onInit() async {
    super.onInit();
  }
}
