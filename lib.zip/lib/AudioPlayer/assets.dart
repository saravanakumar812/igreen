class Links {
  static const String sourceCode =
      'https://github.com/ShokhrukhbekYuldoshev/Meloplay';
}

class Assets {
  static const String logo = 'assets/icon/icon.png';
}