import 'dart:ui';

import 'package:flutter/material.dart';

class HomeScreenResponseModel {
  String? title;
  String? images;
  Color? color;

  HomeScreenResponseModel({this.title, this.images, this.color});
}
