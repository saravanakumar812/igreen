class KeyvaluesOne {
  String key, value;
  bool status;
  KeyvaluesOne({required this.key, required this.value, this.status = true});
}
